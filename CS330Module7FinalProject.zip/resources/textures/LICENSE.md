
Textures 'smiley.png' and 'bandana.png' were created by Jorge Usabiaga for SNHU. Therefore, SNHU owns them and its distribution for commercial and non-commercial purposes.
